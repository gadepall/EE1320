import smbus
import time
# for RPI version 1, use “bus = smbus.SMBus(0)”
bus = smbus.SMBus(1)
vi=5;
b=0;
r1=1000;


# This is the address we setup in the Arduino Program
address1 = 0x04
address2 = 0x05

def readNumber(address):
    number = (bus.read_byte(address))
    return number

while True:
    #var = input("Enter a numeric key to read resistance value :")
    #if not var:
        #continue5
    time.sleep(1)
    
    n=(readNumber(address1)*5)
    vo=(n*vi)/1024.0;
    b=(vi/vo)-1;
    r2=r1/b;
    print ('The resistance value measured 1 is :', r2)

    n=(readNumber(address2)*5)
    vo=(n*vi)/1024.0;
    b=(vi/vo)-1;
    r2=r1/b;
    print ('The resistance value measured 2 is :', r2)
